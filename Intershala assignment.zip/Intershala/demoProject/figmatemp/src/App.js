// // // // import "./App.css";
// // // // import ProfilePage from "./components/profile";
// // // // import "./global.css";
// // // // function App() {
// // // //   return (
// // // //     <div className="App">
// // // //       <ProfilePage />
// // // //     </div>
// // // //   );
// // // // }

// // // // export default App;

// // // // App.js

// // // import React, { useState } from "react";

// // // const App = () => {
// // //   const [activeTab, setActiveTab] = useState("About Me");

// // //   return (
// // //     <div className="flex h-screen bg-gray-900 text-white">
// // //       {/* Left half empty */}
// // //       <div className="hidden lg:block lg:w-1/2"></div>

// // //       {/* Right half content */}
// // //       <div className="lg:w-1/2 w-full p-8">
// // //         {/* Tab Navigation */}
// // //         <div className="flex space-x-4 mb-4">
// // //           {["About Me", "Experiences", "Recommended"].map((tab) => (
// // //             <button
// // //               key={tab}
// // //               className={`py-2 px-4 rounded-md ${
// // //                 activeTab === tab ? "bg-gray-700" : "bg-gray-800"
// // //               }`}
// // //               onClick={() => setActiveTab(tab)}
// // //             >
// // //               {tab}
// // //             </button>
// // //           ))}
// // //         </div>

// // //         {/* Tab Content */}
// // //         <div className="bg-gray-800 p-4 rounded-lg h-48">
// // //           {activeTab === "About Me" && (
// // //             <div>
// // //               <p>
// // //                 Hello! I’m Dave, your sales rep from Salesforce. I've been
// // //                 working at this awesome company for 3 years now.
// // //               </p>
// // //               <p>
// // //                 I was born and raised in Albany, NY. I have been living in Santa
// // //                 Carla for the past 10 years with my wife Tiffany and my twin
// // //                 daughters...
// // //               </p>
// // //             </div>
// // //           )}
// // //           {activeTab === "Experiences" && (
// // //             <p>Experiences content goes here...</p>
// // //           )}
// // //           {activeTab === "Recommended" && (
// // //             <p>Recommended content goes here...</p>
// // //           )}
// // //         </div>

// // //         {/* Gallery Section */}
// // //         <div className="mt-8">
// // //           <div className="flex justify-between items-center">
// // //             <h2 className="text-lg">Gallery</h2>
// // //             <button className="bg-gray-700 py-1 px-4 rounded-md">
// // //               + Add Image
// // //             </button>
// // //           </div>

// // //           <div className="flex space-x-4 mt-4">
// // //             {/* Sample images */}
// // //             <div className="w-24 h-24 bg-gray-700 rounded-md"></div>
// // //             <div className="w-24 h-24 bg-gray-700 rounded-md"></div>
// // //             <div className="w-24 h-24 bg-gray-700 rounded-md"></div>
// // //           </div>
// // //         </div>
// // //       </div>
// // //     </div>
// // //   );
// // // };

// // // export default App;

// // // App.js
// // import React, { useState } from "react";
// // import { FiArrowLeft, FiArrowRight } from "react-icons/fi"; // For arrows
// // import "./global.css";
// // import "./App.css";
// // import { FiHelpCircle } from "react-icons/fi"; // Import question mark icon

// // const App = () => {
// //   const [activeTab, setActiveTab] = useState("About Me");

// //   return (
// //     <div className="flex h-screen bg-gray-900 text-white">
// //       {/* Left half empty */}
// //       <div className="hidden lg:block lg:w-1/2 bg-#616161"></div>

// //       {/* Right half content */}
// //       <div className="lg:w-1/2 w-full p-8">
// //         {/* Question Mark Icon */}

// //         {/* Top Tab Section */}
// //         <div className="mb-8">
// //           {" "}
// //           <div className="bg-gray-800 p-2 rounded-lg shadow-lg h-50 overflow-y-auto custom-scrollbar">
// //             <div className="absolute  p-2">
// //               <FiHelpCircle size={24} className="text-white " />
// //             </div>
// //             {/* Tab Navigation */}
// //             <div className="bg-black p-2 rounded-lg shadow-lg ml-10">
// //               <div className=" flex justify-center space-x-4 ">
// //                 {["About Me", "Experiences", "Recommended"].map((tab) => (
// //                   <button
// //                     key={tab}
// //                     className={`py-2 px-4 rounded-md transition-colors duration-300 ${
// //                       activeTab === tab
// //                         ? "bg-gray-900 text-white"
// //                         : "bg-black text-gray-400 shadow-lg hover:bg-gray-600"
// //                     }`}
// //                     onClick={() => setActiveTab(tab)}
// //                   >
// //                     {tab}
// //                   </button>
// //                 ))}
// //               </div>
// //             </div>
// //             {/* Tab Content */}
// //             <div className="bg-gray-800 p-4 mt-4 rounded-lg h-48 ">
// //               {activeTab === "About Me" && (
// //                 <div>
// //                   <p>
// //                     Hello! I’m Dave, your sales rep from Salesforce. I've been
// //                     working at this awesome company for 3 years now.
// //                   </p>
// //                   <p>
// //                     I was born and raised in Albany, NY. I have been living in
// //                     Santa Carla for the past 10 years with my wife Tiffany and
// //                     my twin daughters... I was born and raised in Albany, NY. I
// //                     have been living in Santa Carla for the past 10 years with
// //                     my wife Tiffany and my twin daughters... I was born and
// //                     raised in Albany, NY. I have been living in Santa Carla for
// //                     the past 10 years with my wife Tiffany and my twin
// //                     daughters... I was born and raised in Albany, NY. I have
// //                     been living in Santa Carla for the past 10 years with my
// //                     wife Tiffany and my twin daughters... I was born and raised
// //                     in Albany, NY. I have been living in Santa Carla for the
// //                     past 10 years with my wife Tiffany and my twin daughters...
// //                     I was born and raised in Albany, NY. I have been living in
// //                     Santa Carla for the past 10 years with my wife Tiffany and
// //                     my twin daughters... I was born and raised in Albany, NY. I
// //                     have been living in Santa Carla for the past 10 years with
// //                     my wife Tiffany and my twin daughters... I was born and
// //                     raised in Albany, NY. I have been living in Santa Carla for
// //                     the past 10 years with my wife Tiffany and my twin
// //                     daughters... I was born and raised in Albany, NY. I have
// //                     been living in Santa Carla for the past 10 years with my
// //                     wife Tiffany and my twin daughters... I was born and raised
// //                     in Albany, NY. I have been living in Santa Carla for the
// //                     past 10 years with my wife Tiffany and my twin daughters...
// //                     I was born and raised in Albany, NY. I have been living in
// //                     Santa Carla for the past 10 years with my wife Tiffany and
// //                     my twin daughters...
// //                   </p>
// //                 </div>
// //               )}
// //               {activeTab === "Experiences" && (
// //                 <p>Experiences content goes here...</p>
// //               )}
// //               {activeTab === "Recommended" && (
// //                 <p>Recommended content goes here...</p>
// //               )}
// //             </div>
// //           </div>
// //         </div>
// //         <div className="flex justify-center">
// //           <div className="h-1 bg-gray-700 w-5/6 my-0.5"></div>
// //         </div>
// //         <br></br>
// //         {/* Gallery Section */}
// //         <div className="bg-gray-800 p-10 rounded-lg shadow-lg">
// //           <div className="absolute  p-2">
// //             <FiHelpCircle size={24} className="text-white" />
// //           </div>
// //           <div className="flex justify-between items-center mb-4 ml-12">
// //             {/* <h2 className="text-lg">Gallery</h2> */}
// //             <button className="bg-black py-2 px-4 rounded-md shadow-lg hover:bg-gray-600 transition-shadow duration-300">
// //               Gallery
// //             </button>
// //             {/* Button group for + Add Image and Arrows */}
// //             <div className="flex items-center space-x-2">
// //               {/* + Add Image Button */}
// //               {/* <button className="bg-gray-600 py-2 px-4 rounded-full shadow-lg hover:bg-gray-600 transition-shadow duration-300">
// //                 + Add Image10
// //               </button> */}
// //               <button className="bg-gray-700 py-2 px-4 rounded-full shadow-[0_4px_8px_rgba(0,0,0,0.6),0_2px_4px_rgba(0,0,0,0.4)] hover:shadow-[0_2px_4px_rgba(0,0,0,0.3)] transform hover:translate-y-1 active:translate-y-0 transition-all duration-300">
// //                 + Add Image
// //               </button>
// //               {/* Left Arrow Icon */}
// //               <button className="bg-gray-900 p-2 rounded-full shadow-[0_4px_8px_rgba(0,0,0,0.6),0_2px_4px_rgba(0,0,0,0.4)] hover:shadow-[0_2px_4px_rgba(0,0,0,0.3)] transform hover:translate-y-1 active:translate-y-0 transition-all duration-300">
// //                 <FiArrowLeft size={20} />
// //               </button>

// //               {/* Right Arrow Icon */}
// //               <button className="bg-gray-900 p-2 rounded-full shadow-[0_4px_8px_rgba(0,0,0,0.6),0_2px_4px_rgba(0,0,0,0.4)] hover:shadow-[0_2px_4px_rgba(0,0,0,0.3)] transform hover:translate-y-1 active:translate-y-0 transition-all duration-300">
// //                 <FiArrowRight size={20} />
// //               </button>
// //             </div>
// //           </div>

// //           {/* Image and Arrow Section */}
// //           <div className="relative">
// //             <div className="flex justify-center space-x-4">
// //               {/* Sample images */}
// //               <div className="w-24 h-24 bg-gray-700 rounded-md"></div>
// //               <div className="w-24 h-24 bg-gray-700 rounded-md"></div>
// //               <div className="w-24 h-24 bg-gray-700 rounded-md"></div>
// //             </div>
// //           </div>
// //         </div>
// //         <br></br>
// //         <div className="flex justify-center">
// //           <div className="h-1 bg-gray-700 w-5/6 my-0.5"></div>
// //         </div>
// //       </div>
// //     </div>
// //   );
// // };

// // export default App;

// import React, { useState } from "react";
// import { FiArrowLeft, FiArrowRight, FiHelpCircle } from "react-icons/fi";
// import "./global.css";
// import "./App.css";

// const App = () => {
//   const [activeTab, setActiveTab] = useState("About Me");

//   return (
//     <div className="flex flex-col lg:flex-row h-screen bg-gray-900 text-white">
//       {/* Left half empty */}
//       <div className="hidden lg:block lg:w-1/2 bg-gray-700"></div>

//       {/* Right half content */}
//       <div className="lg:w-1/2 w-full p-8 flex flex-col space-y-8">
//         {/* Top Section with Question Mark and Tabs */}
//         <div className="flex flex-col">
//           <div className="relative bg-gray-800 p-2 rounded-lg shadow-lg overflow-y-auto custom-scrollbar">
//             <div className="absolute p-2 top-2 left-2">
//               <FiHelpCircle size={24} className="text-white" />
//             </div>
//             {/* Tab Navigation */}
//             <div className="bg-black p-2 rounded-lg shadow-lg ml-10 mt-4 lg:mt-0">
//               <div className="flex justify-center space-x-4">
//                 {["About Me", "Experiences", "Recommended"].map((tab) => (
//                   <button
//                     key={tab}
//                     className={`py-2 px-4 rounded-md transition-colors duration-300 ${
//                       activeTab === tab
//                         ? "bg-gray-900 text-white"
//                         : "bg-black text-gray-400 shadow-lg hover:bg-gray-600"
//                     }`}
//                     onClick={() => setActiveTab(tab)}
//                   >
//                     {tab}
//                   </button>
//                 ))}
//               </div>
//             </div>
//             {/* Tab Content */}
//             <div className="bg-gray-800 p-4 mt-4 rounded-lg h-48">
//               {activeTab === "About Me" && (
//                 <div>
//                   <p>
//                     Hello! I’m Dave, your sales rep from Salesforce. I've been
//                     working at this awesome company for 3 years now.
//                   </p>
//                   <p>
//                     I was born and raised in Albany, NY. I have been living in
//                     Santa Carla for the past 10 years with my wife Tiffany and
//                     my twin daughters...
//                   </p>
//                 </div>
//               )}
//               {activeTab === "Experiences" && (
//                 <p>Experiences content goes here...</p>
//               )}
//               {activeTab === "Recommended" && (
//                 <p>Recommended content goes here...</p>
//               )}
//             </div>
//           </div>
//         </div>

//         {/* Divider Line */}
//         <div className="flex justify-center">
//           <div className="h-1 bg-gray-700 w-full lg:w-5/6"></div>
//         </div>

//         {/* Gallery Section */}
//         <div className="bg-gray-800 p-10 rounded-lg shadow-lg flex flex-col">
//           <div className="absolute p-2 top-2 left-2">
//             <FiHelpCircle size={24} className="text-white" />
//           </div>

//           <div className="flex justify-between items-center mb-4">
//             <button className="bg-black py-2 px-4 rounded-md shadow-lg hover:bg-gray-600 transition-shadow duration-300">
//               Gallery
//             </button>
//             <div className="flex items-center space-x-2">
//               <button className="bg-gray-700 py-2 px-4 rounded-full shadow-lg hover:bg-gray-600 transition-shadow duration-300">
//                 + Add Image
//               </button>
//               <button className="bg-gray-900 p-2 rounded-full shadow-lg hover:bg-gray-600 transition-shadow duration-300">
//                 <FiArrowLeft size={20} />
//               </button>
//               <button className="bg-gray-900 p-2 rounded-full shadow-lg hover:bg-gray-600 transition-shadow duration-300">
//                 <FiArrowRight size={20} />
//               </button>
//             </div>
//           </div>

//           {/* Image Section */}
//           <div className="flex justify-center space-x-4">
//             <div className="w-24 h-24 bg-gray-700 rounded-md"></div>
//             <div className="w-24 h-24 bg-gray-700 rounded-md"></div>
//             <div className="w-24 h-24 bg-gray-700 rounded-md"></div>
//           </div>
//         </div>

//         {/* Second Divider Line */}
//         <div className="flex justify-center">
//           <div className="h-1 bg-gray-700 w-full lg:w-5/6"></div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default App;

import React, { useState } from "react";
import { FiArrowLeft, FiArrowRight, FiHelpCircle } from "react-icons/fi";
import "./global.css";
import "./App.css";

const App = () => {
  const [activeTab, setActiveTab] = useState("About Me");

  return (
    <div className="flex flex-col lg:flex-row min-h-screen lg:h-screen bg-gray-900 text-white">
      {/* Left half empty */}
      <div className="hidden lg:block lg:w-1/2 bg-gray-800"></div>

      {/* Right half content */}
      <div className="lg:w-1/2 w-full p-8 flex flex-col space-y-8">
        {/* Top Section with Question Mark and Tabs */}
        <div className="flex flex-col">
          <div className="relative bg-gray-800 p-2 rounded-lg shadow-lg overflow-y-auto custom-scrollbar">
            <div className="absolute p-2 top-2 left-2">
              <FiHelpCircle size={24} className="text-white" />
            </div>
            {/* Tab Navigation */}
            <div className="bg-black p-2 rounded-lg shadow-lg ml-10 mt-4 lg:mt-0">
              {/* <div className="flex flex-row justify-center space-x-4">
                {["About Me", "Experiences", "Recommended"].map((tab) => (
                  <button
                    key={tab}
                    className={`py-2 px-4 rounded-md transition-colors duration-300 ${
                      activeTab === tab
                        ? "bg-gray-900 text-white"
                        : "bg-black text-gray-400 shadow-lg hover:bg-gray-600"
                    }`}
                    onClick={() => setActiveTab(tab)}
                  >
                    {tab}
                  </button>
                ))}
              </div> */}
              <div className="flex flex-col md:flex-row justify-center space-y-4 md:space-y-0 md:space-x-4">
                {["About Me", "Experiences", "Recommended"].map((tab) => (
                  <button
                    key={tab}
                    className={`py-2 px-4 rounded-md transition-colors duration-300 ${
                      activeTab === tab
                        ? "bg-gray-900 text-white"
                        : "bg-black text-gray-400 shadow-lg hover:bg-gray-600"
                    }`}
                    onClick={() => setActiveTab(tab)}
                  >
                    {tab}
                  </button>
                ))}
              </div>
            </div>
            {/* Tab Content */}
            <div className="bg-gray-800 p-4 mt-4 rounded-lg h-48">
              {activeTab === "About Me" && (
                <div>
                  <p>
                    Hello! I’m Dave, your sales rep from Salesforce. I've been
                    working at this awesome company for 3 years now.
                  </p>
                  <p>
                    I was born and raised in Albany, NY. I have been living in
                    Santa Carla for the past 10 years with my wife Tiffany and
                    my twin daughters... I was born and raised in Albany, NY. I
                    have been living in Santa Carla for the past 10 years with
                    my wife Tiffany and my twin daughters... I was born and
                    raised in Albany, NY. I have been living in Santa Carla for
                    the past 10 years with my wife Tiffany and my twin
                    daughters... I was born and raised in Albany, NY. I have
                    been living in Santa Carla for the past 10 years with my
                    wife Tiffany and my twin daughters... I was born and raised
                    in Albany, NY. I have been living in Santa Carla for the
                    past 10 years with my wife Tiffany and my twin daughters...
                    I was born and raised in Albany, NY. I have been living in
                    Santa Carla for the past 10 years with my wife Tiffany and
                    my twin daughters... I was born and raised in Albany, NY. I
                    have been living in Santa Carla for the past 10 years with
                    my wife Tiffany and my twin daughters...
                  </p>
                </div>
              )}
              {activeTab === "Experiences" && (
                <p>Experiences content goes here...</p>
              )}
              {activeTab === "Recommended" && (
                <p>Recommended content goes here...</p>
              )}
            </div>
          </div>
        </div>

        {/* Divider Line */}
        <div className="flex justify-center">
          <div className="h-1 bg-gray-700 w-full lg:w-5/6"></div>
        </div>

        {/* Gallery Section */}
        <div className="bg-gray-800 p-10 rounded-lg shadow-lg flex flex-col">
          <div className="absolute p-2 -ml-8">
            <FiHelpCircle size={24} className="text-white" />
          </div>

          <div className="flex flex-row justify-between items-center mb-4 ml-10">
            <button className="bg-black py-2 px-4 rounded-md shadow-lg hover:bg-gray-600 transition-shadow duration-300 pb-4">
              Gallery
            </button>
            {/* Button group for + Add Image and Arrows */}
            <div className="flex flex-row items-center space-x-2">
              <button className="bg-gray-700 py-2 px-4 rounded-full shadow-[0_4px_8px_rgba(0,0,0,0.6),0_2px_4px_rgba(0,0,0,0.4)] hover:shadow-[0_2px_4px_rgba(0,0,0,0.3)] transform hover:translate-y-1 active:translate-y-0 transition-all duration-300">
                + Add Image
              </button>
              <button className="bg-gray-900 p-2 rounded-full shadow-[0_4px_8px_rgba(0,0,0,0.6),0_2px_4px_rgba(0,0,0,0.4)] hover:shadow-[0_2px_4px_rgba(0,0,0,0.3)] transform hover:translate-y-1 active:translate-y-0 transition-all duration-300">
                <FiArrowLeft size={20} />
              </button>
              <button className="bg-gray-900 p-2 rounded-full shadow-[0_4px_8px_rgba(0,0,0,0.6),0_2px_4px_rgba(0,0,0,0.4)] hover:shadow-[0_2px_4px_rgba(0,0,0,0.3)] transform hover:translate-y-1 active:translate-y-0 transition-all duration-300">
                <FiArrowRight size={20} />
              </button>
            </div>
          </div>

          {/* Image Section */}
          <div className="flex flex-row justify-center space-x-4">
            <div className="w-24 h-24 bg-gray-700 rounded-md">
              {" "}
              <img src="https://images.unsplash.com/photo-1725536357518-f4811969b4b7?q=80&w=1964&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"></img>
            </div>
            <div className="w-24 h-24 bg-gray-700 rounded-md">
              <img src="https://images.unsplash.com/photo-1725536357518-f4811969b4b7?q=80&w=1964&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"></img>
            </div>
            <div className="w-24 h-24 bg-gray-700 rounded-md">
              <img src="https://images.unsplash.com/photo-1725536357518-f4811969b4b7?q=80&w=1964&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"></img>
            </div>
          </div>
        </div>

        {/* Second Divider Line */}
        <div className="flex justify-center">
          <div className="h-1 bg-gray-700 w-full lg:w-5/6"></div>
        </div>
      </div>
    </div>
  );
};

export default App;
