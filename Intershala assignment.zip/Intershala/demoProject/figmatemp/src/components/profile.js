import React, { useState } from "react";
import { ChevronLeft, ChevronRight, Plus, HelpCircle } from "lucide-react";
import "../App.css";
import "../global.css";

const ProfilePage = () => {
  const [activeTab, setActiveTab] = useState("About Me");
  const tabs = ["About Me", "Experiences", "Recommended"];

  return (
    <div className="bg-black min-h-screen flex p-8">
      {/* Left empty section */}
      <div className="w-1/2 hidden md:block"></div>

      {/* Right section with widgets */}
      <div className="w-full md:w-1/2 space-y-6">
        {/* About Me widget */}
        <div className="bg-gray-900 rounded-xl overflow-hidden">
          <div className="bg-black px-4 py-2 flex justify-between items-center">
            <div className="flex space-x-2">
              {tabs.map((tab) => (
                <button
                  key={tab}
                  className={`px-4 py-2 rounded-full text-sm transition-colors ${
                    activeTab === tab
                      ? "bg-gray-800 text-white"
                      : "text-gray-400 hover:text-white"
                  }`}
                  onClick={() => setActiveTab(tab)}
                >
                  {tab}
                </button>
              ))}
            </div>
            <button className="text-gray-400 hover:text-white">
              <HelpCircle size={20} />
            </button>
          </div>
          <div className="p-6 text-gray-300 text-sm h-40 overflow-y-auto custom-scrollbar">
            {activeTab === "About Me" && (
              <p>
                Hello! I'm Dave, your sales rep here from Salesforce. I've been
                working at this awesome company for 3 years now.
                <br />
                <br />I was born and raised in Albany, NY & have been living in
                Santa Carla for the past 10 years my wife Tiffany and my 4 year
                old twin daughters - Emma and Ella. Both of them are just
                starting school, so my calender is usually blocked between 9-10
                AM. This is...
                {/* Add more text to demonstrate scrolling */}
              </p>
            )}
            {/* Add content for other tabs as needed */}
          </div>
        </div>

        {/* Gallery widget */}
        <div className="bg-gray-900 rounded-xl p-6">
          <div className="flex justify-between items-center mb-6">
            <button className="bg-black text-white px-4 py-2 rounded-lg">
              Gallery
            </button>
            <div className="flex items-center space-x-2">
              <button className="bg-gray-800 hover:bg-gray-700 text-white px-3 py-2 rounded-full shadow-md transition-colors flex items-center space-x-1">
                <Plus size={16} />
                <span className="text-sm">ADD IMAGE</span>
              </button>
              <button className="bg-gray-800 p-2 rounded-full text-white hover:bg-gray-700 transition-colors">
                <ChevronLeft size={20} />
              </button>
              <button className="bg-gray-800 p-2 rounded-full text-white hover:bg-gray-700 transition-colors">
                <ChevronRight size={20} />
              </button>
            </div>
          </div>
          <div className="flex justify-center space-x-4">
            {[1, 2, 3].map((img) => (
              <div
                key={img}
                className="w-24 h-24 bg-gray-800 rounded-lg overflow-hidden"
              >
                <img
                  src="/api/placeholder/96/96"
                  alt="Gallery item"
                  className="w-full h-full object-cover"
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
